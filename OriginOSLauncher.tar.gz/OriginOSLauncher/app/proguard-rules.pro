# OriginOS 7 Launcher ProGuard Rules

# Keep launcher activities
-keep class com.originoslauncher.MainActivity { *; }
-keep class com.originoslauncher.AppDrawerActivity { *; }
-keep class com.originoslauncher.ControlCenterFragment { *; }
-keep class com.originoslauncher.SettingsActivity { *; }

# Keep receivers
-keep class com.originoslauncher.receiver.** { *; }

# Keep models
-keep class com.originoslauncher.model.** { *; }

# Keep custom views
-keep class com.originoslauncher.view.** { *; }

# Keep ViewModel
-keep class com.originoslauncher.viewmodel.** { *; }

# AndroidX
-dontwarn androidx.**
-keep class androidx.** { *; }

# Material Components
-keep class com.google.android.material.** { *; }

# Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { *; }

# Keep Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# Keep data classes
-keepclassmembers class com.originoslauncher.** {
    public synthetic <methods>;
}

# Keep Parcelable
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}
