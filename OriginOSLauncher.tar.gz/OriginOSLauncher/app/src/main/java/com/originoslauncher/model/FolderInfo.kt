package com.originoslauncher.model

data class FolderInfo(
    val id: String,
    val name: String,
    val apps: MutableList<AppInfo> = mutableListOf(),
    var gridPosition: Int = -1
) {
    val previewIcons: List<AppInfo>
        get() = apps.take(4)
}
