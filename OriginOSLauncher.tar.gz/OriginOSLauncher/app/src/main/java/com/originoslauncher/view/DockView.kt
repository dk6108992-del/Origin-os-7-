package com.originoslauncher.view

import android.content.Context
import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.originoslauncher.R
import com.originoslauncher.model.AppInfo
import com.originoslauncher.utils.AnimationUtils

class DockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val maxDockItems = 5

    init {
        orientation = HORIZONTAL
        LayoutInflater.from(context).inflate(R.layout.view_dock, this, true)
        applyBlurBackground()
    }

    private fun applyBlurBackground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val blurEffect = RenderEffect.createBlurEffect(12f, 12f, Shader.TileMode.CLAMP)
            setRenderEffect(blurEffect)
        }
    }

    fun setApps(apps: List<AppInfo>) {
        val container = findViewById<LinearLayout>(R.id.dockContainer)
        container.removeAllViews()

        val displayApps = apps.take(maxDockItems)
        displayApps.forEach { app ->
            val itemView = LayoutInflater.from(context)
                .inflate(R.layout.item_dock_icon, container, false)

            val icon = itemView.findViewById<ImageView>(R.id.dockIcon)
            val label = itemView.findViewById<TextView>(R.id.dockLabel)

            icon.setImageDrawable(app.icon)
            label.text = app.label

            itemView.setOnClickListener {
                AnimationUtils.appLaunchAnimation(icon) {
                    launchApp(app)
                }
            }

            container.addView(itemView)
        }
    }

    private fun launchApp(app: AppInfo) {
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
        intent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(it)
        }
    }
}
