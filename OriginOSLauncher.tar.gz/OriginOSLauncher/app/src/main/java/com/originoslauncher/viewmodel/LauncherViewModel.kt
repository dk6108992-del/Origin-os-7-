package com.originoslauncher.viewmodel

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.Intent
import android.os.Build
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.originoslauncher.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel : ViewModel() {

    private val _allApps = MutableLiveData<List<AppInfo>>()
    val allApps: LiveData<List<AppInfo>> = _allApps

    private val _homeApps = MutableLiveData<List<AppInfo>>()
    val homeApps: LiveData<List<AppInfo>> = _homeApps

    private val _dockApps = MutableLiveData<List<AppInfo>>()
    val dockApps: LiveData<List<AppInfo>> = _dockApps

    private val _filteredApps = MutableLiveData<List<AppInfo>>()
    val filteredApps: LiveData<List<AppInfo>> = _filteredApps

    private val _wallpaperChanged = MutableLiveData<Unit>()
    val wallpaperChanged: LiveData<Unit> = _wallpaperChanged

    private var currentQuery = ""

    fun refreshApps(context: Context) {
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) {
                loadInstalledApps(context)
            }
            _allApps.value = apps
            _filteredApps.value = apps
            updateHomeAndDock(apps)
        }
    }

    private fun loadInstalledApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfoList: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        return resolveInfoList.mapNotNull { info ->
            try {
                AppInfo(
                    packageName = info.activityInfo.packageName,
                    activityName = info.activityInfo.name,
                    label = info.loadLabel(pm).toString(),
                    icon = info.loadIcon(pm),
                    isSystemApp = (info.activityInfo.applicationInfo.flags and
                            android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                )
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.label.lowercase() }
    }

    private fun updateHomeAndDock(apps: List<AppInfo>) {
        // Show first page of apps on home (up to 20)
        _homeApps.value = apps.take(20)

        // Default dock apps: Phone, Messages, Camera, Browser, Settings
        val dockPackages = listOf(
            "com.android.dialer",
            "com.google.android.dialer",
            "com.android.mms",
            "com.google.android.apps.messaging",
            "com.android.camera2",
            "com.google.android.camera",
            "com.android.chrome",
            "com.android.settings"
        )

        val dockApps = dockPackages.mapNotNull { pkg ->
            apps.find { it.packageName == pkg }
        }.take(5)

        _dockApps.value = if (dockApps.isNotEmpty()) dockApps else apps.take(4)
    }

    fun searchApps(query: String) {
        currentQuery = query
        val allAppsList = _allApps.value ?: return
        _filteredApps.value = if (query.isEmpty()) {
            allAppsList
        } else {
            allAppsList.filter {
                it.label.contains(query, ignoreCase = true) ||
                        it.packageName.contains(query, ignoreCase = true)
            }
        }
    }

    fun notifyWallpaperChanged() {
        _wallpaperChanged.value = Unit
    }

    fun notifyPackageAdded(packageName: String, context: Context) {
        refreshApps(context)
    }

    fun notifyPackageRemoved(packageName: String) {
        val current = _allApps.value?.toMutableList() ?: return
        current.removeAll { it.packageName == packageName }
        _allApps.value = current
        _filteredApps.value = current
    }
}
