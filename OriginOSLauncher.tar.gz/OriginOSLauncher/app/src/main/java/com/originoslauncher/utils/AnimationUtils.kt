package com.originoslauncher.utils

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.AccelerateDecelerateInterpolator

object AnimationUtils {

    private const val DURATION_FAST = 200L
    private const val DURATION_NORMAL = 300L
    private const val DURATION_SLOW = 500L

    fun fadeIn(view: View, duration: Long = DURATION_NORMAL, onEnd: (() -> Unit)? = null) {
        view.alpha = 0f
        view.visibility = View.VISIBLE
        view.animate()
            .alpha(1f)
            .setDuration(duration)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { onEnd?.invoke() }
            .start()
    }

    fun fadeOut(view: View, duration: Long = DURATION_NORMAL, onEnd: (() -> Unit)? = null) {
        view.animate()
            .alpha(0f)
            .setDuration(duration)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                view.visibility = View.GONE
                onEnd?.invoke()
            }
            .start()
    }

    fun scaleDown(view: View, targetScale: Float = 0.93f, duration: Long = DURATION_NORMAL) {
        view.animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .setDuration(duration)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    fun scaleUp(view: View, duration: Long = DURATION_NORMAL, onEnd: (() -> Unit)? = null) {
        view.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(duration)
            .setInterpolator(OvershootInterpolator(1.2f))
            .withEndAction { onEnd?.invoke() }
            .start()
    }

    fun slideUpReveal(view: View, duration: Long = DURATION_SLOW) {
        view.translationY = view.height.toFloat().coerceAtLeast(800f)
        view.animate()
            .translationY(0f)
            .setDuration(duration)
            .setInterpolator(DecelerateInterpolator(2f))
            .start()
    }

    fun slideDownDismiss(view: View, duration: Long = DURATION_NORMAL, onEnd: (() -> Unit)? = null) {
        view.animate()
            .translationY(view.height.toFloat().coerceAtLeast(800f))
            .setDuration(duration)
            .setInterpolator(AccelerateInterpolator(2f))
            .withEndAction { onEnd?.invoke() }
            .start()
    }

    fun expandSearchBar(view: View, duration: Long = DURATION_NORMAL) {
        val widthAnimator = ValueAnimator.ofInt(view.width, (view.width * 1.15).toInt())
        widthAnimator.duration = duration
        widthAnimator.interpolator = DecelerateInterpolator()
        widthAnimator.addUpdateListener { animator ->
            val lp = view.layoutParams
            lp.width = animator.animatedValue as Int
            view.layoutParams = lp
        }
        widthAnimator.start()
    }

    fun togglePulse(view: View) {
        view.animate()
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(100L)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100L)
                    .start()
            }
            .start()
    }

    fun appLaunchAnimation(icon: View, onEnd: (() -> Unit)? = null) {
        val scaleX = ObjectAnimator.ofFloat(icon, View.SCALE_X, 1f, 0.8f, 1f)
        val scaleY = ObjectAnimator.ofFloat(icon, View.SCALE_Y, 1f, 0.8f, 1f)
        val animSet = AnimatorSet()
        animSet.playTogether(scaleX, scaleY)
        animSet.duration = DURATION_FAST
        animSet.interpolator = AccelerateDecelerateInterpolator()
        animSet.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                onEnd?.invoke()
            }
        })
        animSet.start()
    }

    fun staggeredEntrance(views: List<View>, delay: Long = 50L) {
        views.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 30f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(DURATION_NORMAL)
                .setStartDelay(index * delay)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    fun bounceIn(view: View, duration: Long = DURATION_NORMAL) {
        view.scaleX = 0f
        view.scaleY = 0f
        view.visibility = View.VISIBLE
        view.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(duration)
            .setInterpolator(OvershootInterpolator(2f))
            .start()
    }
}
