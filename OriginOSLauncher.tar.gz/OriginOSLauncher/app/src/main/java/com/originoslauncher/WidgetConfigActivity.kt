package com.originoslauncher

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.originoslauncher.databinding.ActivityWidgetConfigBinding

class WidgetConfigActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWidgetConfigBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWidgetConfigBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWidgetOptions()
    }

    private fun setupWidgetOptions() {
        // Battery widget
        binding.addBatteryWidget.setOnClickListener {
            // Add battery widget to home screen
            finish()
        }

        // RAM widget
        binding.addRamWidget.setOnClickListener {
            finish()
        }

        // Storage widget
        binding.addStorageWidget.setOnClickListener {
            finish()
        }

        // Clock widget
        binding.addClockWidget.setOnClickListener {
            finish()
        }

        binding.cancelButton.setOnClickListener {
            finish()
        }
    }
}
