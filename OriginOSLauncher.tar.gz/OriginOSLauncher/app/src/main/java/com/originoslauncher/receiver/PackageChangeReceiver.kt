package com.originoslauncher.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.originoslauncher.MainActivity

class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val packageName = intent.data?.schemeSpecificPart ?: return
        val activity = MainActivity.instance ?: return

        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED,
            Intent.ACTION_PACKAGE_CHANGED,
            Intent.ACTION_PACKAGE_REPLACED -> {
                activity.refreshApps()
            }
            Intent.ACTION_PACKAGE_REMOVED -> {
                activity.onPackageRemoved(packageName)
            }
        }
    }
}
