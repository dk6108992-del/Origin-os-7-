package com.originoslauncher.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.originoslauncher.databinding.ItemHomeIconBinding
import com.originoslauncher.model.AppInfo
import com.originoslauncher.utils.AnimationUtils

class HomeIconAdapter(
    private val context: Context,
    private val onAppClick: (AppInfo) -> Unit
) : ListAdapter<AppInfo, HomeIconAdapter.IconViewHolder>(AppDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IconViewHolder {
        val binding = ItemHomeIconBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return IconViewHolder(binding)
    }

    override fun onBindViewHolder(holder: IconViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class IconViewHolder(private val binding: ItemHomeIconBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(app: AppInfo) {
            binding.appIcon.setImageDrawable(app.icon)
            binding.appLabel.text = app.label

            binding.root.setOnClickListener {
                AnimationUtils.appLaunchAnimation(binding.appIcon) {
                    onAppClick(app)
                }
            }

            binding.root.setOnLongClickListener {
                // Long press: show app options (uninstall, info, add to folder)
                showAppOptions(app)
                true
            }
        }

        private fun showAppOptions(app: AppInfo) {
            // Will be implemented via a popup/bottom sheet
        }
    }

    private class AppDiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.packageName == newItem.packageName

        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.label == newItem.label
    }
}
