package com.originoslauncher.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.originoslauncher.databinding.ItemAppDrawerGridBinding
import com.originoslauncher.databinding.ItemAppDrawerListBinding
import com.originoslauncher.model.AppInfo
import com.originoslauncher.utils.AnimationUtils

class AppDrawerAdapter(
    private val context: Context,
    private val onAppClick: (AppInfo) -> Unit
) : ListAdapter<AppInfo, RecyclerView.ViewHolder>(AppDiffCallback()) {

    private var isGridView = true
    private val GRID_VIEW_TYPE = 0
    private val LIST_VIEW_TYPE = 1

    override fun getItemViewType(position: Int): Int =
        if (isGridView) GRID_VIEW_TYPE else LIST_VIEW_TYPE

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == GRID_VIEW_TYPE) {
            val binding = ItemAppDrawerGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            GridViewHolder(binding)
        } else {
            val binding = ItemAppDrawerListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            ListViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val app = getItem(position)
        when (holder) {
            is GridViewHolder -> holder.bind(app)
            is ListViewHolder -> holder.bind(app)
        }
    }

    fun setViewMode(isGrid: Boolean) {
        isGridView = isGrid
        notifyDataSetChanged()
    }

    fun scrollToLetter(letter: Char, recyclerView: RecyclerView) {
        val position = currentList.indexOfFirst {
            it.label.firstOrNull()?.uppercaseChar() == letter
        }
        if (position >= 0) {
            recyclerView.smoothScrollToPosition(position)
        }
    }

    inner class GridViewHolder(private val binding: ItemAppDrawerGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppInfo) {
            binding.appIcon.setImageDrawable(app.icon)
            binding.appLabel.text = app.label
            binding.root.setOnClickListener {
                AnimationUtils.appLaunchAnimation(binding.appIcon) { onAppClick(app) }
            }
        }
    }

    inner class ListViewHolder(private val binding: ItemAppDrawerListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppInfo) {
            binding.appIcon.setImageDrawable(app.icon)
            binding.appLabel.text = app.label
            binding.appPackage.text = app.packageName
            binding.root.setOnClickListener {
                AnimationUtils.appLaunchAnimation(binding.appIcon) { onAppClick(app) }
            }
        }
    }

    private class AppDiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.packageName == newItem.packageName
        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo) =
            oldItem.label == newItem.label
    }
}
