package com.originoslauncher.model

data class WidgetInfo(
    val id: Int,
    val type: WidgetType,
    val columnSpan: Int = 2,
    val rowSpan: Int = 1,
    val gridPosition: Int = -1
)

enum class WidgetType {
    TIME_DATE,
    BATTERY,
    RAM_STORAGE,
    WEATHER,
    MUSIC_PLAYER,
    SEARCH_BAR
}
