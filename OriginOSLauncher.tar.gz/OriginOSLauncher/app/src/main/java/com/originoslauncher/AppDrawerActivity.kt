package com.originoslauncher

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.originoslauncher.adapter.AppDrawerAdapter
import com.originoslauncher.adapter.AlphabetSectionAdapter
import com.originoslauncher.databinding.ActivityAppDrawerBinding
import com.originoslauncher.model.AppInfo
import com.originoslauncher.utils.AnimationUtils
import com.originoslauncher.utils.BlurUtils
import com.originoslauncher.viewmodel.LauncherViewModel

class AppDrawerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppDrawerBinding
    private lateinit var viewModel: LauncherViewModel
    private lateinit var appAdapter: AppDrawerAdapter
    private var isGridView = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.apply {
            addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarColor = android.graphics.Color.TRANSPARENT
            navigationBarColor = android.graphics.Color.TRANSPARENT
        }

        binding = ActivityAppDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[LauncherViewModel::class.java]

        BlurUtils.applyBlurBackground(binding.blurContainer, this)
        setupSearchBar()
        setupRecyclerView()
        setupFab()
        setupObservers()
        setupCloseGesture()

        AnimationUtils.slideUpReveal(binding.drawerContainer)
    }

    private fun setupSearchBar() {
        binding.searchBar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                viewModel.searchApps(s.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.searchBar.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                AnimationUtils.expandSearchBar(binding.searchBarContainer)
            }
        }
    }

    private fun setupRecyclerView() {
        appAdapter = AppDrawerAdapter(this) { app ->
            launchApp(app)
        }

        binding.appList.apply {
            layoutManager = GridLayoutManager(this@AppDrawerActivity, 4)
            adapter = appAdapter
            itemAnimator = null
        }

        // Alphabetical sidebar
        binding.alphabetSidebar.setOnLetterSelectedListener { letter ->
            appAdapter.scrollToLetter(letter, binding.appList)
        }
    }

    private fun setupFab() {
        binding.viewToggleFab.setOnClickListener {
            isGridView = !isGridView
            toggleViewMode()
        }
    }

    private fun toggleViewMode() {
        if (isGridView) {
            binding.appList.layoutManager = GridLayoutManager(this, 4)
            binding.viewToggleFab.setImageResource(R.drawable.ic_list_view)
        } else {
            binding.appList.layoutManager = LinearLayoutManager(this)
            binding.viewToggleFab.setImageResource(R.drawable.ic_grid_view)
        }
        appAdapter.setViewMode(isGridView)
    }

    private fun setupObservers() {
        viewModel.filteredApps.observe(this) { apps ->
            appAdapter.submitList(apps)
            binding.emptyState.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun setupCloseGesture() {
        binding.drawerHandle.setOnClickListener {
            closeDrawer()
        }
        binding.scrimOverlay.setOnClickListener {
            closeDrawer()
        }
    }

    private fun launchApp(app: AppInfo) {
        val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
        launchIntent?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
            overridePendingTransition(R.anim.app_open_enter, R.anim.app_open_exit)
        }
    }

    private fun closeDrawer() {
        AnimationUtils.slideDownDismiss(binding.drawerContainer) {
            finish()
            overridePendingTransition(R.anim.stay, R.anim.slide_down)
        }
    }

    override fun onBackPressed() {
        closeDrawer()
    }
}
