package com.originoslauncher.model

import android.graphics.drawable.Drawable

data class AppInfo(
    val packageName: String,
    val activityName: String,
    val label: String,
    val icon: Drawable?,
    var isSystemApp: Boolean = false,
    var isFavorite: Boolean = false,
    var folder: String? = null,
    var lastUsed: Long = 0L,
    var usageCount: Int = 0
) {
    val firstLetter: Char
        get() = if (label.isNotEmpty()) label.first().uppercaseChar() else '#'
}
