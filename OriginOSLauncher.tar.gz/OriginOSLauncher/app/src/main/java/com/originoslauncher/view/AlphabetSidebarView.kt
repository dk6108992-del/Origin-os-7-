package com.originoslauncher.view

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView
import com.originoslauncher.R

class AlphabetSidebarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val alphabet = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".toList()
    private var onLetterSelected: ((Char) -> Unit)? = null
    private var lastSelected: Char? = null

    init {
        orientation = VERTICAL
        setupLetters()
    }

    private fun setupLetters() {
        alphabet.forEach { letter ->
            val tv = TextView(context).apply {
                text = letter.toString()
                textSize = 10f
                setTextColor(0xAAFFFFFF.toInt())
                gravity = android.view.Gravity.CENTER
                setPadding(8, 2, 8, 2)
                setOnClickListener {
                    onLetterSelected?.invoke(letter)
                    highlightLetter(letter)
                }
            }
            addView(tv)
        }
    }

    private fun highlightLetter(letter: Char) {
        for (i in 0 until childCount) {
            val tv = getChildAt(i) as? TextView ?: continue
            val l = alphabet.getOrNull(i) ?: continue
            tv.setTextColor(if (l == letter) 0xFFFFFFFF.toInt() else 0xAAFFFFFF.toInt())
            tv.textSize = if (l == letter) 12f else 10f
        }
    }

    fun setOnLetterSelectedListener(listener: (Char) -> Unit) {
        onLetterSelected = listener
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val y = event.y
        val index = (y / height * alphabet.size).toInt().coerceIn(0, alphabet.size - 1)
        val letter = alphabet[index]
        if (letter != lastSelected && (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE)) {
            lastSelected = letter
            onLetterSelected?.invoke(letter)
            highlightLetter(letter)
        }
        return true
    }
}
