package com.originoslauncher.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.originoslauncher.databinding.ItemAlphabetLetterBinding

class AlphabetSectionAdapter(
    private val context: Context,
    private val onLetterClick: (Char) -> Unit
) : RecyclerView.Adapter<AlphabetSectionAdapter.LetterViewHolder>() {

    private val letters = ('#'.toString() + "ABCDEFGHIJKLMNOPQRSTUVWXYZ").toList()
    private var selectedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LetterViewHolder {
        val binding = ItemAlphabetLetterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LetterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LetterViewHolder, position: Int) {
        holder.bind(letters[position], position == selectedPosition)
    }

    override fun getItemCount() = letters.size

    inner class LetterViewHolder(private val binding: ItemAlphabetLetterBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(letter: Char, isSelected: Boolean) {
            binding.letter.text = letter.toString()
            binding.letter.alpha = if (isSelected) 1f else 0.5f
            binding.root.setOnClickListener {
                val prev = selectedPosition
                selectedPosition = adapterPosition
                notifyItemChanged(prev)
                notifyItemChanged(selectedPosition)
                onLetterClick(letter)
            }
        }
    }
}
