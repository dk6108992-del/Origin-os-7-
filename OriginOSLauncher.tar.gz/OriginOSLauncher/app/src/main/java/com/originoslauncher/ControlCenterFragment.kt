package com.originoslauncher

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.originoslauncher.databinding.FragmentControlCenterBinding
import com.originoslauncher.utils.AnimationUtils
import com.originoslauncher.utils.BlurUtils
import com.originoslauncher.utils.SystemUtils

class ControlCenterFragment : BottomSheetDialogFragment() {

    private var _binding: FragmentControlCenterBinding? = null
    private val binding get() = _binding!!

    private lateinit var audioManager: AudioManager
    private lateinit var wifiManager: WifiManager
    private var bluetoothAdapter: BluetoothAdapter? = null

    companion object {
        fun newInstance() = ControlCenterFragment()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentControlCenterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        audioManager = requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wifiManager = requireContext().applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        bluetoothAdapter = (requireContext().getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?)?.adapter

        BlurUtils.applyBlurBackground(binding.controlCenterRoot, requireContext())

        setupWifiToggle()
        setupBluetoothToggle()
        setupBrightnessSlider()
        setupVolumeSlider()
        setupDarkModeToggle()
        setupAirplaneToggle()
        setupBatteryInfo()
        setupStorageInfo()
        setupRamInfo()
    }

    private fun setupWifiToggle() {
        val isEnabled = wifiManager.isWifiEnabled
        binding.toggleWifi.isChecked = isEnabled
        updateToggleState(binding.toggleWifi, isEnabled)

        binding.toggleWifi.setOnCheckedChangeListener { _, isChecked ->
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                wifiManager.isWifiEnabled = isChecked
            } else {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
                startActivity(intent)
            }
            updateToggleState(binding.toggleWifi, isChecked)
            AnimationUtils.togglePulse(binding.toggleWifi)
        }

        // Show network name when enabled
        if (isEnabled) {
            val networkInfo = wifiManager.connectionInfo
            val ssid = networkInfo?.ssid?.replace("\"", "") ?: ""
            binding.wifiLabel.text = if (ssid.isNotEmpty()) ssid else "Wi-Fi"
        }
    }

    private fun setupBluetoothToggle() {
        val isEnabled = bluetoothAdapter?.isEnabled == true
        binding.toggleBluetooth.isChecked = isEnabled
        updateToggleState(binding.toggleBluetooth, isEnabled)

        binding.toggleBluetooth.setOnCheckedChangeListener { _, isChecked ->
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.TIRAMISU) {
                if (isChecked) {
                    @Suppress("DEPRECATION")
                    bluetoothAdapter?.enable()
                } else {
                    @Suppress("DEPRECATION")
                    bluetoothAdapter?.disable()
                }
            } else {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                startActivity(intent)
            }
            updateToggleState(binding.toggleBluetooth, isChecked)
            AnimationUtils.togglePulse(binding.toggleBluetooth)
        }
    }

    private fun setupBrightnessSlider() {
        val currentBrightness = try {
            Settings.System.getInt(requireContext().contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Settings.SettingNotFoundException) { 128 }

        binding.brightnessSlider.progress = currentBrightness
        binding.brightnessValue.text = "${(currentBrightness / 255f * 100).toInt()}%"

        binding.brightnessSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.brightnessValue.text = "${(progress / 255f * 100).toInt()}%"
                if (fromUser) {
                    try {
                        Settings.System.putInt(
                            requireContext().contentResolver,
                            Settings.System.SCREEN_BRIGHTNESS,
                            progress
                        )
                        val lp = requireActivity().window.attributes
                        lp.screenBrightness = progress / 255f
                        requireActivity().window.attributes = lp
                    } catch (e: Exception) { }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupVolumeSlider() {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

        binding.volumeSlider.max = maxVolume
        binding.volumeSlider.progress = currentVolume
        binding.volumeValue.text = "${(currentVolume.toFloat() / maxVolume * 100).toInt()}%"

        binding.volumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.volumeValue.text = "${(progress.toFloat() / maxVolume * 100).toInt()}%"
                if (fromUser) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupDarkModeToggle() {
        val currentMode = requireContext().resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK
        val isDark = currentMode == android.content.res.Configuration.UI_MODE_NIGHT_YES

        binding.toggleDarkMode.isChecked = isDark
        updateToggleState(binding.toggleDarkMode, isDark)

        binding.toggleDarkMode.setOnCheckedChangeListener { _, isChecked ->
            val mode = if (isChecked)
                androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
            else
                androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(mode)
            updateToggleState(binding.toggleDarkMode, isChecked)
            AnimationUtils.togglePulse(binding.toggleDarkMode)
        }
    }

    private fun setupAirplaneToggle() {
        val isAirplane = Settings.Global.getInt(
            requireContext().contentResolver,
            Settings.Global.AIRPLANE_MODE_ON, 0
        ) == 1

        binding.toggleAirplane.isChecked = isAirplane
        updateToggleState(binding.toggleAirplane, isAirplane)

        binding.toggleAirplane.setOnCheckedChangeListener { _, _ ->
            startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
        }
    }

    private fun setupBatteryInfo() {
        val batteryLevel = SystemUtils.getBatteryLevel(requireContext())
        val isCharging = SystemUtils.isCharging(requireContext())
        binding.batteryLevel.text = "$batteryLevel%"
        binding.batteryIcon.setImageResource(
            if (isCharging) R.drawable.ic_battery_charging else R.drawable.ic_battery
        )
        binding.batteryProgress.progress = batteryLevel
    }

    private fun setupStorageInfo() {
        val (used, total) = SystemUtils.getStorageInfo()
        val usedPercent = if (total > 0) (used * 100 / total).toInt() else 0
        binding.storageUsed.text = "${SystemUtils.formatBytes(used)} / ${SystemUtils.formatBytes(total)}"
        binding.storageProgress.progress = usedPercent
    }

    private fun setupRamInfo() {
        val (used, total) = SystemUtils.getRamInfo(requireContext())
        val usedPercent = if (total > 0) (used * 100 / total).toInt() else 0
        binding.ramUsed.text = "${SystemUtils.formatBytes(used)} / ${SystemUtils.formatBytes(total)}"
        binding.ramProgress.progress = usedPercent
    }

    private fun updateToggleState(view: View, isEnabled: Boolean) {
        view.alpha = if (isEnabled) 1.0f else 0.5f
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
