package com.originoslauncher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.originoslauncher.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportFragmentManager
            .beginTransaction()
            .replace(binding.settingsContainer.id, LauncherPreferenceFragment())
            .commit()
    }

    class LauncherPreferenceFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.launcher_preferences, rootKey)

            // Icon size
            findPreference<ListPreference>("icon_size")?.setOnPreferenceChangeListener { _, newValue ->
                // Apply icon size change
                true
            }

            // Grid columns
            findPreference<ListPreference>("grid_columns")?.setOnPreferenceChangeListener { _, newValue ->
                // Apply grid columns change
                true
            }

            // Show app labels
            findPreference<SwitchPreferenceCompat>("show_labels")?.setOnPreferenceChangeListener { _, newValue ->
                true
            }

            // Enable blur effects
            findPreference<SwitchPreferenceCompat>("blur_effects")?.setOnPreferenceChangeListener { _, _ ->
                true
            }

            // Dark mode
            findPreference<SwitchPreferenceCompat>("dark_mode")?.setOnPreferenceChangeListener { _, newValue ->
                val isDark = newValue as Boolean
                val mode = if (isDark)
                    androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
                else
                    androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
                androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(mode)
                true
            }
        }
    }
}
