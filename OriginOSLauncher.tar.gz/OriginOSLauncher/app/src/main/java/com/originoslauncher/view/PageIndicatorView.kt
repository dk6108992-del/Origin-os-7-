package com.originoslauncher.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.originoslauncher.R

class PageIndicatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var pageCount = 1
    private var currentPage = 0
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val dotRadius = 4f.dpToPx()
    private val activeDotRadius = 5f.dpToPx()
    private val dotSpacing = 12f.dpToPx()

    init {
        activePaint.color = 0xFFFFFFFF.toInt()
        inactivePaint.color = 0x88FFFFFF.toInt()
    }

    fun setPageCount(count: Int) {
        pageCount = count
        invalidate()
    }

    fun setCurrentPage(page: Int) {
        currentPage = page
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val totalWidth = pageCount * dotSpacing
        var x = (width - totalWidth) / 2f + dotSpacing / 2f
        val cy = height / 2f

        for (i in 0 until pageCount) {
            val paint = if (i == currentPage) activePaint else inactivePaint
            val radius = if (i == currentPage) activeDotRadius else dotRadius
            canvas.drawCircle(x, cy, radius, paint)
            x += dotSpacing
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredHeight = (activeDotRadius * 2 + 8f.dpToPx()).toInt()
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(desiredHeight, MeasureSpec.EXACTLY))
    }

    private fun Float.dpToPx(): Float = this * context.resources.displayMetrics.density
}
