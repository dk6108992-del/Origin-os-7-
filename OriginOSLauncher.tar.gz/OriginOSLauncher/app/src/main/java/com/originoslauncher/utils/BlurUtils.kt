package com.originoslauncher.utils

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.view.View
import androidx.core.content.ContextCompat
import com.originoslauncher.R

object BlurUtils {

    fun applyBlurBackground(view: View, context: Context, radius: Float = 20f) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Use RenderEffect API on Android 12+
            val blurEffect = RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
            view.setRenderEffect(blurEffect)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            // Fallback: set a semi-transparent dark overlay
            view.setBackgroundColor(Color.argb(180, 10, 10, 20))
        }
    }

    fun applyGlassmorphism(view: View, context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val blurEffect = RenderEffect.createBlurEffect(15f, 15f, Shader.TileMode.CLAMP)
            view.setRenderEffect(blurEffect)
        }
        // Set glassmorphism background drawable
        view.background = ContextCompat.getDrawable(context, R.drawable.bg_glassmorphism)
    }

    fun blurBitmap(source: Bitmap, context: Context, radius: Float = 15f): Bitmap {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return source // RenderEffect handles blur at view level
        }

        val outputBitmap = Bitmap.createBitmap(source)
        @Suppress("DEPRECATION")
        val rs = RenderScript.create(context)
        @Suppress("DEPRECATION")
        val blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
        @Suppress("DEPRECATION")
        val input = Allocation.createFromBitmap(rs, source)
        @Suppress("DEPRECATION")
        val output = Allocation.createFromBitmap(rs, outputBitmap)
        blurScript.setRadius(radius.coerceIn(0.1f, 25f))
        blurScript.setInput(input)
        blurScript.forEach(output)
        output.copyTo(outputBitmap)
        rs.destroy()
        return outputBitmap
    }

    fun captureScreenshot(activity: Activity): Bitmap? {
        return try {
            val rootView = activity.window.decorView.rootView
            val bitmap = Bitmap.createBitmap(rootView.width, rootView.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            rootView.draw(canvas)
            bitmap
        } catch (e: Exception) {
            null
        }
    }
}
