package com.originoslauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.originoslauncher.adapter.HomeIconAdapter
import com.originoslauncher.databinding.FragmentHomeBinding
import com.originoslauncher.model.AppInfo
import com.originoslauncher.viewmodel.LauncherViewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: LauncherViewModel
    private lateinit var iconAdapter: HomeIconAdapter
    private var appWidgetHost: AppWidgetHost? = null
    private val APPWIDGET_HOST_ID = 1024
    private val REQUEST_CREATE_APPWIDGET = 5

    companion object {
        fun newInstance() = HomeFragment()
        private const val COLUMNS = 4
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[LauncherViewModel::class.java]

        setupWidgets()
        setupIconGrid()
        setupObservers()
    }

    private fun setupWidgets() {
        appWidgetHost = AppWidgetHost(requireContext(), APPWIDGET_HOST_ID)
        appWidgetHost?.startListening()

        // Add default widgets (battery, time, date)
        addTimeWidget()
    }

    private fun addTimeWidget() {
        // Time/Date widget at top
        val timeView = layoutInflater.inflate(R.layout.widget_time_date, binding.widgetArea, false)
        binding.widgetArea.addView(timeView)
    }

    private fun setupIconGrid() {
        iconAdapter = HomeIconAdapter(requireContext()) { app ->
            launchApp(app)
        }

        binding.iconGrid.apply {
            layoutManager = GridLayoutManager(requireContext(), COLUMNS)
            adapter = iconAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun setupObservers() {
        viewModel.homeApps.observe(viewLifecycleOwner) { apps ->
            iconAdapter.submitList(apps)
        }
    }

    private fun launchApp(app: AppInfo) {
        val intent = requireContext().packageManager.getLaunchIntentForPackage(app.packageName)
        intent?.let {
            it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            // Apply OriginOS-style launch animation
            startActivity(it)
            requireActivity().overridePendingTransition(R.anim.app_open_enter, R.anim.app_open_exit)
        }
    }

    override fun onResume() {
        super.onResume()
        appWidgetHost?.startListening()
    }

    override fun onPause() {
        super.onPause()
        appWidgetHost?.stopListening()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
