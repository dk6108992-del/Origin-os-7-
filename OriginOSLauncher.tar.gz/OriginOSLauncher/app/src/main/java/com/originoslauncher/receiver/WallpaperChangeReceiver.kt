package com.originoslauncher.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.originoslauncher.MainActivity

class WallpaperChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_WALLPAPER_CHANGED) {
            MainActivity.instance?.viewModel?.notifyWallpaperChanged()
        }
    }
}
