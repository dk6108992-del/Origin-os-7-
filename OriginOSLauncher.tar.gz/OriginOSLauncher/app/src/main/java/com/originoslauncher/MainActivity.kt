package com.originoslauncher

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.originoslauncher.databinding.ActivityMainBinding
import com.originoslauncher.utils.AnimationUtils
import com.originoslauncher.viewmodel.LauncherViewModel
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    internal lateinit var viewModel: LauncherViewModel
    private lateinit var gestureDetector: GestureDetector
    private var currentPage = 0
    private var totalPages = 1

    companion object {
        var instance: MainActivity? = null
        const val SWIPE_THRESHOLD = 100
        const val SWIPE_VELOCITY_THRESHOLD = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this

        setupWindow()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[LauncherViewModel::class.java]

        loadWallpaper()
        setupGestureDetector()
        setupHomeScreen()
        setupDock()
        setupIndicators()
        setupObservers()
        viewModel.refreshApps(this)
    }

    private fun setupWindow() {
        window.apply {
            addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    )
        }
    }

    private fun loadWallpaper() {
        try {
            val wallpaperManager = WallpaperManager.getInstance(this)
            val wallpaperDrawable: Drawable? = wallpaperManager.drawable
            binding.wallpaperView.setImageDrawable(wallpaperDrawable)
        } catch (e: Exception) {
            binding.wallpaperView.setBackgroundColor(0xFF1A1A2E.toInt())
        }
    }

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                val diffY = e2.y - (e1?.y ?: 0f)
                val diffX = e2.x - (e1?.x ?: 0f)

                if (abs(diffY) > abs(diffX)) {
                    if (diffY < -SWIPE_THRESHOLD && abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        openAppDrawer()
                        return true
                    } else if (diffY > SWIPE_THRESHOLD && abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        openControlCenter()
                        return true
                    }
                }
                return false
            }

            override fun onLongPress(e: MotionEvent) {
                showHomeEditMode()
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHomeScreen() {
        val homeFragment = HomeFragment.newInstance()
        supportFragmentManager.beginTransaction()
            .replace(binding.fragmentContainer.id, homeFragment)
            .commit()

        binding.root.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false
        }
    }

    private fun setupDock() {
        viewModel.dockApps.observe(this) { apps ->
            binding.dockView.setApps(apps)
        }
    }

    private fun setupIndicators() {
        binding.pageIndicator.setPageCount(totalPages)
        binding.pageIndicator.setCurrentPage(currentPage)
    }

    private fun setupObservers() {
        viewModel.wallpaperChanged.observe(this) {
            loadWallpaper()
        }
    }

    fun openAppDrawer() {
        val intent = Intent(this, AppDrawerActivity::class.java)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_up, R.anim.stay)
    }

    private fun openControlCenter() {
        val controlCenter = ControlCenterFragment.newInstance()
        controlCenter.show(supportFragmentManager, "control_center")
    }

    private fun showHomeEditMode() {
        AnimationUtils.scaleDown(binding.fragmentContainer)
        binding.editModeBar.visibility = View.VISIBLE
        AnimationUtils.fadeIn(binding.editModeBar)
    }

    fun exitHomeEditMode() {
        AnimationUtils.scaleUp(binding.fragmentContainer)
        AnimationUtils.fadeOut(binding.editModeBar) {
            binding.editModeBar.visibility = View.GONE
        }
    }

    fun refreshApps() {
        viewModel.refreshApps(this)
    }

    fun onPackageRemoved(packageName: String) {
        viewModel.notifyPackageRemoved(packageName)
    }

    override fun onBackPressed() {
        // Do nothing on home screen back press
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
