# OriginOS 7 Launcher — Build Instructions

## Overview

This is a fully-functional Android launcher APK project inspired by Vivo OriginOS 7.
It targets Android 13–16 (API 33–34) and includes all source code, resources, and Gradle build files.

---

## Requirements

| Tool | Version |
|------|---------|
| Android Studio | Hedgehog (2023.1.1) or newer |
| Kotlin | 1.9.22 |
| Gradle | 8.4 |
| Android SDK | API 34 (compile), API 33 (min) |
| Java | JDK 17 |

---

## Steps to Build the APK

### Option A — Android Studio (Recommended)

1. **Clone / extract** this project folder
2. **Open** Android Studio → File → Open → select `OriginOSLauncher/`
3. Android Studio will auto-detect the Gradle project and sync dependencies
4. **Create `local.properties`** (rename `local.properties.template` to `local.properties` and set `sdk.dir` to your Android SDK path)
5. **Sync Gradle**: Click "Sync Now" in the banner or go to File → Sync Project with Gradle Files
6. **Build APK**:
   - Debug APK: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Release APK: Build → Generate Signed Bundle / APK → APK → follow signing wizard
7. APK output location: `app/build/outputs/apk/debug/app-debug.apk`

### Option B — Command Line

```bash
# Set up local.properties first
echo "sdk.dir=/path/to/your/Android/Sdk" > local.properties

# Make gradlew executable
chmod +x gradlew

# Build debug APK
./gradlew assembleDebug

# Build release APK (requires signing keystore)
./gradlew assembleRelease
```

---

## Setting as Default Launcher

After installing the APK on your device:

1. Go to **Settings → Apps → Default Apps → Home App**
2. Select **OriginOS 7 Launcher**
3. Or when you press the Home button, select it from the system chooser dialog

---

## Features Implemented

### Home Screen
- OriginOS-style app icon grid (4-column, configurable)
- Large clock + date widget at the top
- Custom page indicator dots
- Long-press to enter edit mode (add widgets, change wallpaper)

### App Drawer
- Swipe up from home screen to open
- Glassmorphism blur background
- Grid / List view toggle
- Real-time search bar
- Alphabetical A-Z sidebar for fast scrolling
- Smooth slide-up / slide-down animation

### Control Center
- Swipe down from home screen
- Wi-Fi toggle (Android 11+ redirects to Settings due to OS restriction)
- Bluetooth toggle
- Dark mode toggle
- Airplane mode toggle
- Brightness slider
- Volume slider
- Battery level + charging status widget
- RAM usage widget
- Storage usage widget

### Dock
- Bottom dock with up to 5 favorite apps
- Glassmorphism rounded background
- Auto-populates with Phone, Messages, Camera, Browser, Settings

### Animations (120Hz optimized)
- App launch scale animation
- Slide-up drawer reveal
- Smooth fade transitions
- Staggered icon entrance
- Toggle pulse feedback

### Dark / Light Mode
- Full dark mode (default, OriginOS-style)
- Light mode toggle in Control Center and Settings
- Night-mode resource overrides

### Settings
- Icon size (Small / Normal / Large / XL)
- Grid columns (3–6)
- Show/hide app labels
- Enable/disable blur effects
- Enable/disable transition animations
- Set as default launcher shortcut

---

## Architecture

```
com.originoslauncher/
├── MainActivity.kt          — Root launcher activity
├── HomeFragment.kt          — Home screen with icons + widgets
├── AppDrawerActivity.kt     — Full-screen app drawer
├── ControlCenterFragment.kt — Bottom-sheet control panel
├── SettingsActivity.kt      — Preferences screen
├── WidgetConfigActivity.kt  — Widget picker
├── adapter/                 — RecyclerView adapters
├── model/                   — Data classes (AppInfo, FolderInfo, WidgetInfo)
├── receiver/                — BroadcastReceivers (boot, package changes, wallpaper)
├── utils/                   — BlurUtils, AnimationUtils, SystemUtils
├── view/                    — Custom views (DockView, PageIndicatorView, AlphabetSidebarView)
└── viewmodel/               — LauncherViewModel (app list, search, refresh)
```

---

## Permissions Required (all declared in AndroidManifest.xml)

| Permission | Purpose |
|-----------|---------|
| `QUERY_ALL_PACKAGES` | Load all installed app icons |
| `READ_EXTERNAL_STORAGE` | Wallpaper access |
| `CHANGE_WIFI_STATE` | Wi-Fi toggle |
| `BLUETOOTH_CONNECT` | Bluetooth toggle (Android 12+) |
| `RECEIVE_BOOT_COMPLETED` | Restart launcher on boot |
| `PACKAGE_USAGE_STATS` | App usage stats (optional, for smart sort) |
| `EXPAND_STATUS_BAR` | Control center drag |
| `VIBRATE` | Haptic feedback |

---

## Notes for Low-End Devices

- Blur effects via `RenderEffect` API (Android 12+) gracefully degrade to semi-transparent overlays on older hardware
- `RenderScript` blur fallback for Android 8–11
- `largeHeap="true"` in manifest for better memory headroom
- ProGuard minification + resource shrinking in release builds
- `hardwareAccelerated="true"` at application level
- RecyclerView with `DiffUtil` for efficient list updates

---

## Troubleshooting

**Gradle sync fails**: Ensure your `local.properties` has the correct `sdk.dir` path.

**Missing `gradle-wrapper.jar`**: In Android Studio, go to File → Project Structure → Gradle settings and let Studio regenerate the wrapper, or run `gradle wrapper --gradle-version 8.4` if you have Gradle installed globally.

**APK installs but doesn't show in Home chooser**: Make sure the `<category android:name="android.intent.category.HOME" />` intent filter is in the manifest (it is) and restart your device.

**Bluetooth toggle not working on Android 13+**: This is an OS restriction. The app redirects to Bluetooth Settings — this is the correct behavior for Android 13+ apps.

---

## License

This project is provided for educational and personal use. Not affiliated with Vivo or OriginOS.
